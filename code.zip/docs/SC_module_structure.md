/backend

  /modules
  
    auth.js
    admin.js
    workflow.js
    scheduler.js
    executor.js
    
    cubes/
    
       loaders.js
       recognizers.js
       ai_cubes.js
       savers.js
       decider.js
       math.js
       
    analytics.js
    logger.js
    anonymizer.js
    
  /middleware
  
    accessControl.js
    anonymize.js
    
  /routes
  
    authRoutes.js
    workflowRoutes.js
    executionRoutes.js
    
  /utils
  
    typeValidator.js
    outputFormatter.js
